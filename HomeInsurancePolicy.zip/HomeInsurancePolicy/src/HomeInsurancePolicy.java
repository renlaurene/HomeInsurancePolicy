
public class HomeInsurancePolicy {
	private String policyNumber; // X4569A; 
	private double coverageAmount; //600,000.0; 
	private double homeValue; // 700,000.00; 
	
	public HomeInsurancePolicy(String policyNumber, double coverageAmount, double homeValue){
		this.policyNumber = policyNumber;
		this.coverageAmount = coverageAmount;
		this.homeValue = homeValue; 	
	}
	
	//Override Object's toString method
	public String toString(){
		return "Policy numer: " + policyNumber + "Coverage Amount:" +coverageAmount + "homeValue" + homeValue; 
	}
	//Override Object's equals() methods 
	public boolean equals(Object obj){
		HomeInsurancePolicy tstPolicy;
		
		if(!(obj instanceof HomeInsurancePolicy)) return false; 
		tstPolicy = (HomeInsurancePolicy) obj;
		//Two insurance policies can be considered equal if they have same policy number
		if(tstPolicy.policyNumber == policyNumber) return true;
		return false; 
	}
	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public double getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(double coverageAmount) {
		this.coverageAmount = coverageAmount;
	}

	public double getHomeValue() {
		return homeValue;
	}

	public void setHomeValue(double homeValue) {
		this.homeValue = homeValue;
	}

	public static void main(String[] args) {		
		}		
}
