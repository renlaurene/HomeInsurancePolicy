
public class HomInsuPolicyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HomeInsurancePolicy tst1 = new HomeInsurancePolicy("X4569A", 600000.0, 700000.0);
		HomeInsurancePolicy tst2 = new HomeInsurancePolicy("X4569A", 600000.0, 700000.0);
		HomeInsurancePolicy tst3 = new HomeInsurancePolicy("X4569B", 800000.0, 900000.0);
		
		System.out.println(tst1);
		if(tst1.equals(tst2)){
			System.out.println(tst2);
			System.out.println("The two home insurance polies are the same" +"\n");
		}else{
			System.out.println("The two home insurance polies are NOT the same" );
		}
		
		System.out.println(tst3);
		if(tst2.equals(tst3)){
			System.out.println("\n The two home insurance polies are the same");
		}else{
			System.out.println(tst2);
			System.out.println("The two home insurance polies are NOT the same" );
		}
	}
}
